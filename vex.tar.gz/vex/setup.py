from distutils.core import setup

setup(name='vex', version='1.2', description='VEX Parser',
      author='Mark Kettenis', author_email='kettenis@jive.nl',
      py_modules=['vex', 'MultiDict'])
